//
//  CameraController.swift
//  OpenCV
//
//  Created by Dmytro Nasyrov on 5/1/17.
//  Copyright © 2017 Pharos Production Inc. All rights reserved.
//

import UIKit

public final class CameraController: UIViewController {

}
