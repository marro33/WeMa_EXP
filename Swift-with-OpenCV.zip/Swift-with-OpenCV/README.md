# Swift-with-OpenCV
Demo project that shows how to add OpenCV into swift iOS app. You can find more details at Medium:
[Using OpenCV in a Swift project](https://medium.com/pharos-production/using-opencv-in-a-swift-project-679868e1b798)


成功导入了opencv.framework
设置Framework search paths, Header Search Paths
在runscript里去掉

